---
title: Status Humanizacji Plików .md w Projekcie Regulujemy.pl
author: Tomasz Jakubowski
publish folder: null
category: null
utworzono: 2025-07-25 12:34
zmodyfikowano: 2025-07-28 07:50
icon:
aliases: Status Humanizacji Plików .md w Projekcie Regulujemy.pl
---
# Status Humanizacji Plików .md w Projekcie Regulujemy.pl

## Data ostatniej aktualizacji: 28 lipca 2025

## Status:

- uslugi/naprawa-okien/wymiana-uszczelek.md: humanized
- uslugi/naprawa-okien/naprawa-zawiasow.md: humanized
- uslugi/naprawa-okien/naprawa-pcv.md: humanized
- uslugi/naprawa-okien/naprawa-okuc.md: humanized
- uslugi/naprawa-okien/naprawa-klamek.md: humanized
- produkty/systemy/index.md: humanized
- produkty/okucia/index.md: humanized
- produkty/drzwi/drzwi-zewnetrzne-drewniane.md: humanized
- produkty/okna/okna-pcv.md: humanized
- produkty/okna/okna-aluminiowe.md: humanized
- produkty/okna/okna-drewniane.md: humanized
- uslugi/montaz-sprzedaz/montaz-fasad.md: humanized
- uslugi/naprawa-okien/wymiana-szyb.md: humanized
- uslugi/specjalistyczne/automatyka-okienna.md: humanized
- uslugi/regulacja-okien/regulacja-zaawansowana.md: humanized
- uslugi/regulacja-okien/regulacja-podstawowa.md: humanized
- uslugi/regulacja-okien/regulacja-drewniane.md: humanized
- blog/poradniki/dlaczego-okno-sie-zacina.md: humanized
- lokalizacje/warszawa/_pakiety-promocyjne.md: humanized
- lokalizacje/warszawa/Białołęka.md: humanized
- lokalizacje/warszawa/_checklist-przygotowanie.md: humanized
- strony/certyfikaty.md: humanized
- strony/gwarancja.md: humanized
- strony/o-nas.md: humanized
- strony/promocje.md: humanized
- strony/opinie.md: humanized
- lokalizacje/inne-miasta.md: humanized
- lokalizacje/krakow.md: humanized
- lokalizacje/poznan.md: humanized
- lokalizacje/gdansk.md: humanized
- lokalizacje/index.md: humanized
- biznes/biura-lokale-komercyjne.md: humanized
- biznes/index.md: humanized
- biznes/instytucje-publiczne.md: humanized
- biznes/umowy-serwisowe.md: humanized
- biznes/wspolnoty-mieszkaniowe.md: humanized
- blog/diagnostyka/test-okna-5-minut.md: humanized
- blog/index.md: humanized
- blog/poradniki/jak-sprawdzic-czy-okno-wymaga-regulacji.md: humanized
- blog/poradniki/kiedy-regulowac-okna.md: humanized
- lokalizacje/warszawa/Bielany.md: humanized
- lokalizacje/warszawa/Mokotów.md: humanized
- lokalizacje/warszawa/bemowo.md: humanized
- lokalizacje/warszawa/index.md: humanized
- lokalizacje/warszawa/ochota.md: humanized
- produkty/uszczelki/index.md: humanized
- produkty/szyby/index.md: humanized
- produkty/index.md: humanized
- strony/faq.md: humanized
- strony/kontakt.md: humanized
- strony/cennik.md: humanized
- uslugi/techniczne/szyby-pakiety.md: humanized
- lokalizacje/warszawa/ursus.md: humanized
- lokalizacje/warszawa/wlochy.md: humanized
- uslugi/index.md: humanized
- index.md: humanized
- uslugi/montaz-sprzedaz/index.md: humanized
- uslugi/regulacja-okien/regulacja-pcv.md: humanized
- uslugi/regulacja-okien/index.md: humanized
- uslugi/naprawa-okien/index.md: humanized
- uslugi/wymiana-czesci/index.md: humanized