---
title: Drzwi Zewnętrzne Aluminiowe - Nowoczesne, Pasywne, Antywłamaniowe | Regulujemy.pl
description: "Nowoczesne drzwi zewnętrzne aluminiowe w systemach MB-86, MB-104, MB-SKYLINE. Drzwi pasywne, antywłamaniowe, zintegrowane ze Smart Home. Profesjonalny montaż."
keywords: ["drzwi zewnętrzne aluminiowe", "drzwi aluminiowe", "drzwi pasywne", "drzwi antywłamaniowe", "drzwi pivot", "drzwi bezprogowe", "montaż drzwi aluminiowych"]
---
# DRZWI ZEWNĘTRZNE ALUMINIOWE

## Nowoczesny Design • Trwałość • Bezpieczeństwo

## NAWIGACJA
[Start](../../index.md) > [Produkty](../index.md) > [Drzwi](Regulujemy.pl/produkty/drzwi/index.md) > **Drzwi Zewnętrzne Aluminiowe**

Drzwi zewnętrzne aluminiowe to idealne rozwiązanie dla tych, którzy cenią sobie nowoczesny design, wyjątkową trwałość i najwyższy poziom bezpieczeństwa. Dzięki swoim właściwościom, aluminium pozwala na tworzenie konstrukcji o dużych gabarytach i minimalistycznym wyglądzie, idealnie wpisujących się w architekturę domów pasywnych, energooszczędnych oraz luksusowych rezydencji. Oferujemy drzwi aluminiowe wiodących systemów, które łączą estetykę z doskonałymi parametrami izolacyjnymi i antywłamaniowymi.

### Systemy profili – wybierz idealne rozwiązanie dla siebie

- **MB-86 - Standard Premium:** To doskonały wybór dla domów jednorodzinnych i apartamentów. System o głębokości 77mm (rama) i 86mm (skrzydło) zapewnia izolacyjność Ud od 0,9 W/m²K. Charakteryzuje się wysoką izolacyjnością termiczną i akustyczną, a także szeroką gamą kolorystyczną. Cena: od 2400 zł netto.
- **MB-104 Passive - Dla Wymagających:** Jeśli budujesz dom pasywny lub energooszczędny, ten system jest dla Ciebie. Z głębokością 95mm (rama) i 104mm (skrzydło), osiąga izolacyjność Ud od 0,72 W/m²K, co potwierdza certyfikat Instytutu Domów Pasywnych w Darmstadt. Spełnia najostrzejsze normy budowlane i pozwala na stosowanie paneli o grubości do 95mm. Cena: od 3600 zł netto.
- **MB-SKYLINE - Design i Prestiż:** To rozwiązanie dla luksusowych rezydencji i nowoczesnej architektury. System o głębokości 77mm (rama) i 86mm (skrzydło) oferuje izolacyjność Ud od 0,85 W/m²K. Wyróżnia się ukrytymi zawiasami, minimalistycznym designem i możliwością tworzenia drzwi o wysokości do 3,2m, zlicowanych z ościeżnicą. Cena: od 4800 zł netto.

### Wypełnienia drzwiowe – estetyka i funkcjonalność

Oferujemy różnorodne wypełnienia, które pozwolą Ci spersonalizować wygląd drzwi:

- **Panele wsadowe:** Dostępne w wersji gładkiej (lakierowane w kolorze drzwi, z pianką poliuretanową 60mm), z frezowaniem (wzory geometryczne, organiczne, indywidualne, wykonane technologią CNC) oraz z aplikacjami INOX (ze stali nierdzewnej, w formie pasków, ramek czy intarsji).
- **Przeszklenia:** Oferujemy pakiety 3-szybowe (Ug=0,5 W/m²K, z szybami antywłamaniowymi P4A, piaskowanymi, ornamentowymi, dźwiękochłonnymi do 45 dB) oraz pakiety 4-szybowe (Ug=0,3 W/m²K, z szybami antywłamaniowymi P6B, lakierowanymi, barwionymi, dźwiękochłonnymi do 47 dB).

### Kolorystyka i wykończenie – dopasuj do swojego stylu

- **Paleta RAL:** Ponad 200 kolorów do wyboru, w wykończeniu matowym, satynowym, połyskowym lub strukturalnym. Technologia malowania proszkowego gwarantuje trwałość na 15-20 lat.
- **Lakiery drewnopodobne:** Ponad 20 wzorów (dąb, orzech, mahoń) z efektem struktury drewna 3D. Trwałość 10-15 lat.
- **Anodowanie:** Dostępne w 10 kolorach (srebro, złoto, brąz, czarny), z naturalnym metalicznym połyskiem. Zapewnia trwałość ponad 25 lat i odporność na zarysowania.

### Akcesoria i dodatki – komfort i bezpieczeństwo

- **Okucia:** Pochwyty ze stali nierdzewnej, klamki zintegrowane z czytnikiem linii papilarnych, klamki z podświetleniem LED.
- **Zamki:** Automatyczne wielopunktowe (AV3), elektromechaniczne z kontrolą dostępu, biometryczne (na odcisk palca).
- **Przeszklenia:** Szyby antywłamaniowe P4A, P6B, kuloodporne BR4, hartowane ESG, dźwiękochłonne (do 47 dB), przeciwsłoneczne (Stopsol), z powłokami samoczyszczącymi, sitodrukiem ceramicznym, szprosami międzyszybowymi, ornamentami piaskowanymi, lustrami weneckimi.

### Rozwiązania specjalne – dla najbardziej wymagających

- **Drzwi Pivot (od 6500 zł):** Z przesuniętą osią obrotu, tworzące wrażenie lewitacji. Skrzydła do 500 kg i wysokości do 4m.
- **Drzwi Bezprogowe (od 3200 zł):** Z progiem zlicowanym z posadzką, idealne dla osób niepełnosprawnych. Zapewniają maksymalną szczelność i odprowadzenie wody.
- **Drzwi Łukowe (wycena indywidualna):** Z górnym przeszkleniem łukowym, dopasowane do architektury. Produkcja na zamówienie, termin 8-10 tygodni.

### Smart Home Ready – inteligentne rozwiązania

Nasze drzwi mogą być zintegrowane z systemami Smart Home (KNX/EIB, Fibaro, Somfy TaHoma, Control4, Loxone), oferując funkcje takie jak otwieranie na zbliżenie (NFC), harmonogramy dostępu, powiadomienia push, integracja z alarmem i sterowanie głosowe.

### Proces realizacji – od projektu do montażu

1.  **Konsultacja projektowa (GRATIS):** Analiza potrzeb, dobór systemu i wstępna wycena.
2.  **Projekt techniczny (3-5 dni):** Rysunki techniczne, wizualizacja 3D i specyfikacja.
3.  **Produkcja (6-8 tygodni):** Precyzyjna produkcja z kontrolą jakości i testem przedmontażowym.
4.  **Montaż certyfikowany (1-2 dni):** Montaż przez ekipę producenta, poziomowanie laserowe, regulacja i testy.

### Cennik orientacyjny 2025

| System | Wymiar | Wykończenie | Cena netto | Cena brutto |
|---|---|---|---|---|
| MB-86 | 1000x2100 | Anodowane | 2400 zł | 2952 zł |
| MB-86 | 1200x2100 | RAL | 2850 zł | 3506 zł |
| MB-104 | 1000x2100 | Anodowane | 3600 zł | 4428 zł |
| MB-104 | 1200x2100 | Drewnopodobne | 4900 zł | 6027 zł |
| MB-SKYLINE | 1000x2100 | Anodowane | 4800 zł | 5904 zł |
| MB-SKYLINE | 1200x2400 | RAL Special | 6200 zł | 7626 zł |

*Ceny zawierają montaż w Warszawie i okolicach*

### Gwarancja i serwis

Na nasze drzwi udzielamy kompleksowej gwarancji:

- **Profile i powłoki:** 15 lat
- **Okucia i mechanizmy:** 5 lat
- **Szyby zespolone:** 10 lat
- **Montaż:** 5 lat
- **Elektronika:** 2 lata

Oferujemy również przeglądy gwarancyjne co 2 lata, serwis pogwarancyjny oraz dostępność części zamiennych przez ponad 20 lat.

### FAQ - Najczęściej zadawane pytania

**Jaka jest różnica między systemami MB-86, MB-104 i MB-SKYLINE?**
Główna różnica to głębokość profili i parametry termoizolacyjne. MB-104 to system pasywny, a MB-SKYLINE to rozwiązanie premium z minimalistycznym designem.

**Czy można zamówić nietypowe wymiary?**
Tak, produkujemy drzwi na wymiar do 1600x3200mm (szerokość x wysokość). Większe wymiary wymagają indywidualnej konsultacji.

**Jak długo trwa realizacja zamówienia?**
Standardowo 6-8 tygodni. Kolory specjalne i wykończenia indywidualne mogą wydłużyć czas do 10-12 tygodni.

**Czy montujecie poza Warszawą?**
Tak, dojeżdżamy w promieniu 150 km od Warszawy. Dalsze lokalizacje po uzgodnieniu.

## Zamów drzwi swoich marzeń

**Skontaktuj się z nami już dziś!**

> **[📞 ZADZWOŃ: 123-456-789]**
> 
> **[🏢 UMÓW WIZYTĘ W SHOWROOMIE](../../strony/kontakt.md)**
> 
> **[📐 ZAMÓW PROJEKT ONLINE](../../strony/kontakt.md)**

---

### Zobacz także:
- [Fasady aluminiowe](../../uslugi/montaz-sprzedaz/montaz-fasad.md)
- [Drzwi wewnętrzne aluminiowe](drzwi-wewnetrzne-aluminiowe.md)
- [Okna aluminiowe](../../produkty/okna/okna-aluminiowe.md)
- [Smart Home integracje](../../uslugi/dodatkowe/smart-home-integracja.md)

---

**Regulujemy.pl** - Tworzymy wejścia, które robią wrażenie!
